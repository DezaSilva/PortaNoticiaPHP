<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    include_once './classes/util/Conexao.class.php';
    include_once './classes/repository/NoticiaRepository.class.php';
    include_once './classes/entity/Noticia.class.php';
    //include_once './classes/entity/CadastroUsuario.php';
    include_once './classes/application/MaterNoticiasService.class.php';
    //include_once './classes/application/ManterUsuarioService.class.php';
    include_once './classes/exceptions/ViolacaoNegocioException.class.php';
    //include_once'./classes/repository/CadastroUsuarioRepository.class.php';
    $conexao = new Conexao();
    
?>