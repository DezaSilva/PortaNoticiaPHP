<?php include_once "includes.php";

$noticiaService = new MaterNoticiasService($conexao);

echo "<pre>";
print_r($noticiaService->listarUltimas());