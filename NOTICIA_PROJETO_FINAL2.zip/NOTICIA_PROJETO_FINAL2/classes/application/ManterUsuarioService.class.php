<?php


class MaterUsuarioService{
    
    function __construct($conexao){
    $this->cadastroUsuarioRepository = new CadastroUsuarioRepository($conexao);
        
    }
    
    function incluirUsuario(Usuario $CadastroUsuario){
        
        $cadastroUsuario->validate();
        $this->CadastroUsuarioRepository->incluir($CadastroUsuario);
    }

}