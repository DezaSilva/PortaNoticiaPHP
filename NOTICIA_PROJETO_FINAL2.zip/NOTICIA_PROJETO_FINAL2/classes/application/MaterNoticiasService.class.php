<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of MaterNoticiasService
 *
 * @author andreza
 */
class MaterNoticiasService {
    //put your code here
    
   
    private  $noticiaRepository;
    
    function __construct($conexao) {
        $this->noticiaRepository = new NoticiaRepository($conexao);
    }
    
    function incluirNoticia(Noticia $noticia){
        $noticia->validate();
        $this->noticiaRepository->incluir($noticia);
    }
    
    function listarUltimas(){
        return $this->noticiaRepository->listarUltimas();
    }
    

}
