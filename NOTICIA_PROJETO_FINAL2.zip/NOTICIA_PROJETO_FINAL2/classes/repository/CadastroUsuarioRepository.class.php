<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CadastroUsuarioRepository
 *
 * @author andreza
 */
class CadastroUsuarioRepository {
   
    private $conexao;
    
}
function __construct($conexao){
    $this->conexao = $conexao;
}

 function incluirUsuario($usuario){
        $query = "INSERT INTO usuario (Nome, Email, Senha) values(?,?,?)";
      
          
        if ($stmt = $this->conexao->getMysqli()->prepare($query)) {
            $stmt->bind_param("sss", $usuario->getNome(), 
                                     $usuario->getEmail(), 
                                     $usuario->getSenha()
                                     );
            $stmt->execute();
        }else{
        
            throw new Exception("erro no prepare: ". $this->conexao->getMysqli()->error );
        }
   
    }
    
