<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of NoticiaRepository
 *
 * @author andreza
 */
class NoticiaRepository {
    
    private $conexao;
    private $NUMERO_MAXIMO_NOTICIAS = 5;
    
    function __construct($conexao) {
        $this->conexao = $conexao;
    }
    
    function incluir($noticia){
        $query = "INSERT INTO noticia (titulo, texto, autor, data) values(?,?,?,?)";
      
          
        if ($stmt = $this->conexao->getMysqli()->prepare($query)) {
            $stmt->bind_param("ssss", $noticia->getTitulo(), 
                                     $noticia->getTexto(), 
                                     $noticia->getAutor(),
                                     $noticia->getData()
                                     );
            $stmt->execute();
        }else{
        
            throw new Exception("erro no prepare: ". $this->conexao->getMysqli()->error );
        }
   
    }
    
   
    function listarUltimas(){
        $retorno = array();
        $query = "SELECT id, titulo, texto, autor, data FROM noticia "
                . "ORDER BY id DESC LIMIT ". $this->NUMERO_MAXIMO_NOTICIAS;
        
        if ($stmt = $this->conexao->getMysqli()->prepare($query)) {
            
            $stmt->execute();
            $stmt->bind_result($id, $titulo, $texto, $autor, $data);
            
            //$id = result.getInt(0); 
            while ($stmt->fetch()) {
                $retorno[] = new Noticia($id, $titulo, $texto, $autor, $data, null);
            }
        }else{
            throw new Exception("erro no prepare: ". $this->conexao->getMysqli()->error );
        }
        
        
        return $retorno;

   
    }
}
