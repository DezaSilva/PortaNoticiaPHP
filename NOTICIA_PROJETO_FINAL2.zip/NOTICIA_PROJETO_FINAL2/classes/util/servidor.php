<?php

$Usuario = $_SESSION["usuario"];
$Senha = $_SESSION["Senha"];

if(isset($Usuario) && isset($Senha)){
    
    echo"<script> alert(\"faca lg\")</script>";
}


?>