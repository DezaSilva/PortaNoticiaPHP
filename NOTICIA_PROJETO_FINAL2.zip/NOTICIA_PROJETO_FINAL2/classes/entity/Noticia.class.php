<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Noticia
 *
 * @author andreza
 */
class Noticia {
    
    private $id;
    private $titulo;
    private $texto;
    private $imagem;
    private $autor;
    private $data;

    function __construct($id, $titulo, $texto, $autor, $data, $imagem=null) {
        $this->id = $id;
        $this->titulo = $titulo;
        $this->texto = $texto;
        $this->imagem = $imagem;
        $this->autor = $autor;
        $this->data = $data;
    }
    
    function validate(){
        $msg = "ERRO NO CADASTRO DA NOTICIA: ";
       
        if(trim($this->titulo) == "" || $this->titulo == null){
            throw new ViolacaoNegocioException($msg . " DIGITE UM TITULO VÁLIDO");
        }
    }
    
    function __toString() {
        return $this->id . " - ". $this->titulo . " - " . $this->autor;
    }
    
    function getAutor() {
        return $this->autor;
    }
    
    function getData() {
        return $this->data;
    }
  

    function setData($data) {
        $this->data = $data;
    }

    function setAutor($autor) {
        $this->autor = $autor;
    }

    function getId() {
        return $this->id;
    }

    function getTitulo() {
        return $this->titulo;
    }
    function setId($id) {
        $this->id = $id;
    }

    function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    function setTexto($texto) {
        $this->texto = $texto;
    }

    function setImagem($imagem) {
        $this->imagem = $imagem;
    }

    function getTexto() {
        return $this->texto;
    }

    function getImagem() {
        return $this->imagem;
    }


}
