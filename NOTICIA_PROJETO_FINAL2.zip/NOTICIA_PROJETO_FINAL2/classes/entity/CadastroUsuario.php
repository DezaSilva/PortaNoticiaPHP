<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CadastroUsuario
 *
 * @author andreza
 */
class CadastroUsuario {

    private $ID;
    private $Nome;
    private $Email;
    private $Senha;

}

function __construct($ID, $Nome, $Email, $Senha) {

    $this->id = $ID;
    $this->nome = $Nome;
    $this->email = $Email;
    $this->senha = $Senha;
}

function validate(){
        $msg = "ERRO AO CADASTRAR USUARIO: ";
       
        if(trim($this->Nome) == "" || $this->Nome == null){
            throw new ViolacaoNegocioException($msg . " DIGITE  SEU NOME");
        }
    }
    
 function __toString() {
        return $this->id . " - ". $this->Nome . " - " . $this->Email;
    }    

function getID() {
    return $this->id;
}

function getNome() {
    return $this->nome;
}

function getEmail() {
    return $this->nome;
}

function getSenha() {
    return $this->senha;
}

function setID($ID) {
    $this->id = $ID;
}

function setNome($Nome) {
    $this->nome = $Nome;
}

function setEmail($Email) {
    $this->email = $Email;
}

function setSenha($Senha) {
    $this->senha = $Senha;
}
