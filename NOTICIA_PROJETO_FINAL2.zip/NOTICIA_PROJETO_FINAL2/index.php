<?php include_once "includes.php";

$noticiaService = new MaterNoticiasService($conexao);

$noticias = $noticiaService->listarUltimas();
?>
 <!DOCTYPE html>
  <html lang="pt-BR">
   <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Noticias</title>

    <link href="css/estilo.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/paginaNoticia.css" type="text/css" rel="stylesheet">


    <script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
    <header>
        <div class="container">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <img alt="Brand" src="img/e1.jpg" id="logo" class="img-rounded">
                        <h1 class="portal"> Seu portal de notícias</h1>
                        <p>OLÁ SEJA BEM VINDO(A) <a href="login.php">FAÇA LOGIN</a> OU <a href="cadastrar.php">CADASTRE-SE</a>.</p>
                        <img class="img-responsive img-circle" id="img" src="img/logo.png" alt="logo noticia">
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-6">
                <br>
                <img class="img-responsive" alt="Dilma Roussef" src="img/dilma.jpg">
                <h1 class="titulo">Anastasia diz que assunto Lava Jato será 'abordado' em parecer</h1>
                <p>O relator do processo de impeachment no Senado, senador Antonio Anastasia (PSDB-MG), afirmou na noite desta sexta-feira (29) que o assunto “Lava Jato” será abordado em seu relatório. O parlamentar,no entanto, não especificou de que forma o tema será tratado no parecer.</p>
                <p>Anastasia concedeu entrevista coletiva<a class="link" href="http://g1.globo.com/politica/processo-de-impeachment-de-dilma/noticia/2016/04/em-comissao-do-impeachment-ministros-negam-crime-de-dilma.html" <strong=""> após a sessão que ouviu a defesa da presidente Dilma Rousseff</a> na comissão que discute o impedimento da petista. Para governistas, não é possível incluir a Lava Jato como mais um dos temas da denúncia, que originalmente trata somente das chamadas 'pedaladas fiscais' e dos decretos de créditos suplementares liberados sem a aprovação do Congresso Nacional.</p>
                <p>Anastasia comentou a Lava Jato ao ser perguntado se ainda é possível incluir novos fatos ao objeto da denúncia contra Dilma, como elementos da operação que investiga esquema de corrupção na Petrobras. “Esse tema é um dos temas que vai ser abordado no meu relatório”, respondeu o senador. "Então é possível [incluir a Lava Jato]?”, questinou o repórter. “Vai ser abordado o assunto, não estou dizendo em que sentido”, completou Anastas</p>
                <p>Ao depor na comissão do impeachment nesta quinta-feira (28), a jurista Janaína Paschoal, co-autora do pedido de impedimento de Dilma, disse que que os <a class="link" href="http://g1.globo.com/politica/processo-de-impeachment-de-dilma/noticia/2016/04/analise-do-impeachment-deve-levar-em-conta-lava-jato-diz-janaina.html" <strong="">senadores devem levar em conta</a>, no julgamento, as investigações da operação Lava Jato. O senador Cássio Cunha Lima (PSDB-PB), líder do PSDB, defendeu, também na quinta-feira, que o Senado acrescente as denúncias da operação Lava Jato na atual fase do processo, na comissão especial.</p>
                <p>O presidente da comissão, senador Raimundo Lira (PMDB-PB), no entanto, afirmou nesta sexta que<a class="link" href="http://g1.globo.com/politica/processo-de-impeachment-de-dilma/noticia/2016/04/denuncia-contra-dilma-nao-pode-ser-ampliada-na-fase-da-comissao-diz-lira.html" <strong=""> não haverá ampliação da denúncia</a> contra a presidente Dilma Rousseff nessa primeira fase na comissão. “Nesta primeira fase da comissão, eu já defini, respondi a uma questão de ordem, que a denúncia da Câmara dos Deputados não poderia mudar o foco, não poderia ser ampliada. O assunto que o relator vai tratar é exclusivamente em relação as chamadas pedaladas e aos seis decretos”, afirmou.</p>
            </div>
            <div class="col-xs-12 col-md-6">
                <h1 class="titulo">Ministros contestam na comissão do impeachment tese de crime de Dilma</h1>
                <p>Os ministros José Eduardo Cardozo (Advocacia Geral da União), Nelson Barbosa (Fazenda) e Kátia Abreu (Agricultura) negaram nesta sexta-feira (29), em sessão da comissão especial do impeachment do Senado que a presidente Dilma Rousseff tenha cometido crime de responsabilidade.</p>
                <p>Pelo segundo dia consecutivo, dedicado à apresentação da defesa da presidente, houve troca de farpas e acusações ao longo das quase dez horas de duração da sessão, mas o clima foi mais tranquilo do que na quinta-feira (28), quando episódios de bate-boca marcaram os depoimentos, pela acusação, dos juristas Miguel Reale Júnior e Janaína Paschoal, autores do pedido de impeachment.
                </p>
                <img class="img-responsive" alt="Ministro" src="img/ministro.jpg">
                <h4>Fazenda</h4>
                <p>O primeiro a falar pela defesa de Dilma foi o ministro da Fazenda. Barbosa rejeitou as acusações de que a presidente tenha praticado crime de responsabilidade por editar decretos de crédito suplementar no ano passado sem autorização do Congresso Nacional e por atrasar pagamentos aos bancos públicos – prática conhecida como "pedaladas fiscais". Esses dois pontos fundamentam o pedido de impeachment.</p>
                <p>As chamadas "pedaladas fiscais" são manobras de atraso de repasses do Tesouro Nacional a bancos públicos para pagar benefícios sociais, que acabam melhorando artificialmente a situação fiscal do país. O governo, no entanto, nega que essas operações contábeis tivessem o objetivo de maquiar as contas públicas.</p>
                <p>Barbosa defendeu que os decretos de crédito suplementar foram compatíveis com a legislação em vigor, tinham base nas fontes legais de recursos e não representaram novas despesas.</p>
            </div>
        </div>
    </div>
    <hr>
    <footer>
        <p class="text-muted">© 2016 - Desenvolvido por Jonatha, Andreza , Edvan</p>

        <div class="panel-body"  >
            <h4>Links</h4>
            <ul class="list-unstyled">
                <li><a href="#">Home</a>
                </li>
                <li><a href="#">Fale conosco</a>
                </li>
                <li><a href="#">Facebook</a>
                </li>
                <li><a href="#">Twitter</a>
                </li>
            </ul>
        </div>

    </footer>
    </body>
</html>
