<hmtl lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <title>Portal do Usuário</title>
        <link  href="css/estilo.css" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-md-4"></div>
                <div class="col-xs-12 col-md-4">
                    <form method="post" action="login.php" class="form-signin">
        <h2 class="form-signin-heading">Entre com sua conta</h2>
        <label for="inputEmail" class="sr-only">Endereço de e-mail</label>
        <input type="email" id="inputEmail" name="email" class="form-control" placeholder="E-mail" required autofocus>
        <label for="inputPassword" name="senha" class="sr-only">Senha</label>
        <input type="password" id="inputPassword" class="form-control" placeholder="Senha" required>
        <div class="checkbox">
          <label>
            <input type="checkbox" value="remember-me"> Manter conectado
          </label>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Entrar</button>
      </form>

    </div>
        </div>
        </div>        
    </body>
</hmtl>